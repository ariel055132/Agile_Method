package ncu.cs.agile;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestUI {

	@Test
	public void testUI1() {
		assertNotNull (new UI());
	}
	
}
