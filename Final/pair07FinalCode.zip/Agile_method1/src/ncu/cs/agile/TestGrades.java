package ncu.cs.agile;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestGrades {

	@Test
	public void testGrades1() {
		assertNotNull (new Grades()); 
	}

}
