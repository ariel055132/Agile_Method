package ncu.cs.agile;

// does not contain this ID
public class IDExceptions3 extends Exception{

}
