package p1;

public class Exceptions1 extends Exception {

}
