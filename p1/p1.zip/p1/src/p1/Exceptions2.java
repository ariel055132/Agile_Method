package p1;

public class Exceptions2 extends Exception {

}
