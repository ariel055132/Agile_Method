package p1;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		C o1 = new C();
		o1.add(6);
		
	}

}
