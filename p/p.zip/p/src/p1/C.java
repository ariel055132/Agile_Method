package p1;

public class C {
	int a = 3;
	public C() {
		
	}
	public int add(int b) {
		return (this.a+b);
	}
	public int times(int c) {
		int sum = 0;
		// use addition to solve multiplication problem
		for(int i=1;i<=c;i++) {	
			sum += this.a;  
		}
		return sum;
	}
}
